from flask import Flask,render_template
app = Flask(__name__)

@app.route('/')
def start_page():
    return 'start page'

@app.route('/main')
def main_page():
    return render_template('index.html')

app.run(host='192.168.55.89')