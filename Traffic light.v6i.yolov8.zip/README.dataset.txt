# Traffic light > 2023-05-11 2:26am
https://universe.roboflow.com/test-yhcuj/traffic-light-ke5b5

Provided by a Roboflow user
License: CC BY 4.0

